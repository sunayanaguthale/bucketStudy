package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.User;
import com.example.demo.exception.UserNotFoundException;
import com.example.demo.repository.UserRepository;

@Service
public class UserService
{
	@Autowired
	UserRepository repo;
	
	public List<User> getAllUser() {
		
		return repo.findAll();
	}

	
	public String addUser(User user)
	{
		User saveUser = repo.save(user);
		return "User Details Added Successfully"+"Your user id is "+user.getUserId();
	}
	
	
	public User updateUser(int userId, User user)
	{
		User existingUser = repo.findById(userId).orElse(null);
		
		if(existingUser==null)
		{
			throw new UserNotFoundException("User not found with ID: "+userId);
		}

		existingUser.setUserId(user.getUserId());
		existingUser.setUsername(user.getUsername());
		existingUser.setEmail(user.getEmail());
		existingUser.setPassword(user.getPassword());
		existingUser.setPhoneno(user.getPhoneno());
		
		return repo.save(existingUser);
	}
	
	public void deleteUser(int userId)
	{
		User existingUser=repo.findById(userId).orElse(null);
		if(existingUser==null)
		{
			throw new UserNotFoundException("User not found with ID: "+userId);
		}
		repo.deleteById(userId);
		System.out.println("User Deleted Successfully");
		
	}
	
	
	public boolean loginAdmin(String username, String password) {
     Optional<User> admin=repo.findByUsername(username);
	 return admin.isPresent() && admin.get().getPassword().equals(password);
	}
}
