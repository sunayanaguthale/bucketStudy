package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.UserService;

@RestController
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	UserService serv;	
	
	@PostMapping("/login")
	public String login(@RequestParam String username,@RequestParam String password)
	{
		if(serv.loginAdmin(username, password))
		{
			return "Login Successfull!";
		
		}
		return "Invalid credentials!";
	}
}
